console.log("JS Loaded");

console.log(document.querySelector(".hero"));

console.log(document.querySelector("header"));

console.log(document.querySelector(".hero-content"));
const header = document.querySelector("header");

window.addEventListener("scroll", () => {
    if (window.scrollY > 50) {
        header.classList.add("sticky");
    } else {
        header.classList.remove("sticky");
    }
});

// ===============================
// Active Navigation
// ===============================

const navLinks = document.querySelectorAll("nav a");

navLinks.forEach(link => {
    link.addEventListener("click", function () {
        navLinks.forEach(item => item.classList.remove("active"));
        this.classList.add("active");
    });
});

// ===============================
// Hero Animation
// ===============================

window.addEventListener("load", () => {

    const heroContent = document.querySelector(".hero-content");

    if(heroContent){
        heroContent.style.opacity = "0";
        heroContent.style.transform = "translateY(40px)";

        setTimeout(() => {
            heroContent.style.transition = "1s";
            heroContent.style.opacity = "1";
            heroContent.style.transform = "translateY(0)";
        },300);
    }

});

// ===============================
// Scroll Reveal Animation
// ===============================

const revealElements = document.querySelectorAll(
".card, .product-card, .box, .review");
/*function reveal() {
    revealElements.forEach(el => {
        if (el.getBoundingClientRect().top < window.innerHeight - 100) {
            el.classList.add("show");
        }
    });
}

window.addEventListener("scroll", reveal);
window.addEventListener("load", reveal);

window.addEventListener("scroll",reveal);
reveal();*/
document.querySelectorAll(".card, .product-card, .box, .review").forEach(el => {
    el.classList.add("show");
});
// ===============================
// Back To Top Button
// ===============================

const topBtn = document.getElementById("topBtn");

if(topBtn){

window.addEventListener("scroll",()=>{

    if(window.scrollY > 400){

        topBtn.style.display="flex";

    }else{

        topBtn.style.display="none";

    }

});

topBtn.addEventListener("click",()=>{

    window.scrollTo({
        top:0,
        behavior:"smooth"
    });

});

}

// ===============================
// Smooth Scroll
// ===============================

document.querySelectorAll('a[href^="#"]').forEach(anchor=>{

anchor.addEventListener("click",function(e){

e.preventDefault();

const target=document.querySelector(this.getAttribute("href"));

if(target){

target.scrollIntoView({

behavior:"smooth"

});

}

});

});
alert("JavaScript Working");